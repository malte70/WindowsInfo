#!python.exe
# -*- coding: utf-8 -*-

from cx_Freeze import setup, Executable
from subprocess import call

WindowsInfo_exe = Executable(
    script = "WindowsInfo.pyw",
    base = "Win32GUI",
    compress = True,
    copyDependentFiles = True,
    appendScriptToExe = False,
    appendScriptToLibrary = False,
    icon = "ressources\WinInfo.ico"
    )

setup(
        name = "Windows Info",
        version = "0.1",
        description = "Get some Information about the windows copy",
        author = "Malte Bublitz",
        author_email = "me@malte70.tk",
        maintainer = "Malte Bublitz",
        maintainer_email = "me@malte70.tk",
        url = "http://malte70.tk/WindowsInfo/index.html",
        download_url = "http://malte70.tk/WindowsInfo/download.html/latest",
        license = "MIT",
        executables = [WindowsInfo_exe]
        )
